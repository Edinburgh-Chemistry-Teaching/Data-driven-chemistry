## Unit 02 Learning Objectives

* Interact with a Jupyter notebook
* Declare variables
* Print variables
* Getting help
* Read data from a file