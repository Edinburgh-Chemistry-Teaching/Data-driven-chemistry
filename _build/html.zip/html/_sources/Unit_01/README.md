## Unit 01 Learning Objectives

- Interact with a Jupyter notebook
- Break a complex problem into smaller steps;
- Consider how those steps might be implemented as code (developed more later in the course);
- Use pseudocode to develop simple algorithms