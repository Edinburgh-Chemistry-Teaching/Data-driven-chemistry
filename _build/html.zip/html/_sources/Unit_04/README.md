## Unit 04 Learning Objectives

**Part I**

* understand inbuilt functions 
* understand the format of a function
* input into functions
* using loops and conditionals in functions
* calling a function

**Part II**

* getting information out of a function
* how to write reusable code
* write functions to interrogate data
