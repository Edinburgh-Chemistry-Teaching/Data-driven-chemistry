## Unit 06 Learning Objectives

* Be confident in computing statistical properties of a dataset
* Know how to plot a histogram and box-plot
* Use the Student's t-test in Python to compare datasets
* Recap of how to read data
* Recap of how to plot basic data